function calc(){
    
    var numAlunos = parseInt(document.getElementById("nai").value);
    var numTurmas = parseInt(document.getElementById("nti").value);

    
    var pessoasPorTurma = Math.floor(numAlunos / numTurmas);
    var pessoasSemTurma = numAlunos % numTurmas;


    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultados</h2>" +
        "<p>Quantidade de pessoas por turma: " + pessoasPorTurma + "</p>" +
        "<p>Quantidade de pessoas sem turma: " + pessoasSemTurma + "</p>";
}