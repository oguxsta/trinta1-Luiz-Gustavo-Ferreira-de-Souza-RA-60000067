function calcular(){

    var DA = parseFloat(document.getElementById("input.d").value);

    
    var a1 = DA * 1.01;
    var a2 = DA * 1.02;
    var a5 = DA * 1.05;
    var a10 = DA * 1.10;

    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultados</h2>" +
        "<p>1% ficará em: " + a1.toFixed(2) + "</p>" +
        "<p>2% ficará em: " + a2.toFixed(2) + "</p>" +
        "<p>5% ficará em: " + a5.toFixed(2) + "</p>" +
        "<p>10% ficará em: " + a10.toFixed(2) + "</p>";
}