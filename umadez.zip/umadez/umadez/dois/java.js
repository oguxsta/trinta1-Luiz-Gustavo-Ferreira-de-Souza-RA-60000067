function calcular(){
    var QP = parseInt(document.getElementById("QPC").value);

    var queijo = QP * 2;
    var ovo = QP * 50; 

    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Ingredientes Necessários</h2>" +
        "<p>Para " + QP + " pessoa(s), você precisa de:</p>" +
        "<p>" + queijo + " Queijo</p>" +
        "<p>" + ovo + " gramas de ovo</p>";
}