function VPI(){
    var numero = parseInt(document.getElementById("ninput").value);

    var msg;

    if (numero % 2 === 0) {
        msg = "O numero é par.";
    } else {
        msg = "O numero é impar.";
    }

    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>V. de Par ou Ímpar</h2>" +
        "<p>" + msg + "</p>";
}