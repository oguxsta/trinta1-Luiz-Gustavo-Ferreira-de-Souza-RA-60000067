function Vnota(){
    var nota = parseFloat(document.getElementById("Noinput").value);

    var msg;

    if (nota > 6) {
        msg = "Aprovado";
    } else if (nota >= 4 && nota <= 6) {
        msg = "Refazer prova";
    } else {
        msg = "Reprovado";
    }

    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultado</h2>" +
        "<p>" + msg + "</p>";
}
