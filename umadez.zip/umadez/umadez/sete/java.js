function CN(){
    var num1 = parseInt(document.getElementById("n1input").value);
    var num2 = parseInt(document.getElementById("n2input").value);

    var mensagem;

    if (num1 > num2) {
        mensagem = "O primeiro número é maior que o segundo.";
    } else if (num1 < num2) {
        mensagem = "O primeiro número é menor que o segundo.";
    } else {
        mensagem = "Os dois números são iguais.";
    }

    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h3>Resultado</h3>" +
        "<p>" + mensagem + "</p>";
}