function calc() {
    
    var VV = parseFloat(document.getElementById("valorVendidoInput").value);
    var meta = parseFloat(document.getElementById("metaInput").value);
    var metaMinima = parseFloat(document.getElementById("metaMinimaInput").value);

    
    var percentualMeta = (VV / meta) * 100;
    var percentualMetaMinima = (VV / metaMinima) * 100;

   
    if (VV >= meta) {
        msg = "meta foi atingida.";
    } else if (VV >= metaMinima) {
        msg = "A meta minima foi atingida.";
    } else {
        msg = "Nenhuma das metas foi atingida.";
    }


    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultados</h2>" +
        "<p>" + msg + "</p>" +
        "<p>Atingimento da meta: " + percentualMeta.toFixed(2) + "%</p>" +
        "<p>Atingimento da meta mínima: " + percentualMetaMinima.toFixed(2) + "%</p>";
}