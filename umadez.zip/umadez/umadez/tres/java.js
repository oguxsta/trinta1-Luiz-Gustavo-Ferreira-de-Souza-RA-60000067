function calcular(){
    var n1 = parseInt(document.getElementById("n1").value);
    var n2 = parseInt(document.getElementById("n2").value);

    var soma = n1 + n2;
    var subtracao = n1 - n2;
    var multiplicacao = n1 * n2;
    var divisao = n1 / n2;

    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h4>Respostas das Operações Matemáticas</h4>" +
        "<p>Soma: " + soma + "</p>" +
        "<p>Subtração: " + subtracao + "</p>" +
        "<p>Multiplicação: " + multiplicacao + "</p>" +
        "<p>Divisão: " + divisao + "</p>";
}